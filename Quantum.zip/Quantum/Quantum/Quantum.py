import speech_recognition as sr
r= sr.Recognizer()
with sr.Microphone() as source:
    print("Dinliyor...")
    audio=r.record(source,duration=4)
    try:
        str=r recognize_google(audio,language="tr-tr")
        print(str)
    except:
      print("bir hata var")

