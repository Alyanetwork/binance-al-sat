### Requirements

The only requirements to install and run Zenbot are

- Linux / macOS 10 / Windows (or Docker)
- [Node.js](https://nodejs.org/) (version 8.3.0 or higher)
- [MongoDB](https://www.mongodb.com/)



#### Recommendations

- It is recommend to use a 64-bit processor (and OS), because a 32-bit OS will limit the database to 2GB.
