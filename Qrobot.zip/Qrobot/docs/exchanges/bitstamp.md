# Zenbot Tips for Bitstamp

The following tips can increase reliability in using Zenbot with Bitstamp.

## 0 Balance

This is often an indication of a mistake in your conf `c.bitstamp.client_id` value. 

This value should be set to the value of your Customer ID. You can find this ID by going to My Account in Bitstamp: https://www.bitstamp.net/account/balance/

