Product = str
""" ETH-BTC or BTC-CUR"""

Selector = str
""" <exchange>.<product> like gdax.ETH-BTC """
