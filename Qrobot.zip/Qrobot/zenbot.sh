#!/bin/sh
env node zenbot.js $@
